# Please donate a small money for poor Ukrainian woman.

If you want to support me, you can't do that because I live in Russia ![](ru.png) and our banks are banned for US, EU and some other countries.
But you, however, can help Anna Kovach, a poor and sick woman I know in Ukraine ![](ua.png) with some money.

She has a heart disease and diabetes, she lives in the city of Rakhiv, Transcarpathian region of Ukraine (West). Her disability pension is about $100 per month. This money is not enough for food and medicine, and Ukraine today is not such a rich country to provide sufficient financial assistance to the disabled.

She has only daughter. Husbent died.

![Anna Kovach](anna-kovach.jpg)
<sub><sup>I also have no way to help her, because due to the military conflict, money transfers to Ukraine from Russia are currently illegal.</sup></sub>

![](https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-100px.png)
Her daughter Diana recently created a paypal account: diana.kola@icloud.com

If you want to talk with them directly, you can send me an [e-mail](mailto:voltasar@gmail.com) and I will give you her contact number (Anna has Whatsapp, but understands only Russian and Ukrainian).